
# [深度求索 (快捷指令)](https://www.icloud.com/shortcuts/b75899492ead45ef9a47cfce89334bf0)

使用DeepSeek API 来增强 Siri 能力的快捷指令.

## UI

![siri3](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/155953822/657bf7f8-3a2b-4757-9acc-7b6548574a0b)




## 配置 deepseek API
## 添加该快捷指令后，填入你自己的DeepSeek API Key即可。使用时可以用文本输入，也可以使用Siri唤醒后语音输入。
![siri1](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/155953822/bfc74639-e85b-4cba-89dc-1a286d17307d)

![siri2](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/155953822/0e483340-858e-424e-9c46-386b6464bfa3)


