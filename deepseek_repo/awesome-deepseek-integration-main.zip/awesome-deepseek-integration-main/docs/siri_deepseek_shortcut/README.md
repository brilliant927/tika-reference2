
# [深度求索 (shortcut)](https://www.icloud.com/shortcuts/b75899492ead45ef9a47cfce89334bf0)

A shortcut to enhance Siri's capabilities with the DeepSeek API.

## UI

![siri3](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/155953822/c76a1a87-3f0e-49c2-a2a1-2685289ab022)



## Integrate with Deepseek API
## After adding the shortcut to the 'Shortcuts' app,  fill in your own DeepSeek API key.Then you can use it in text or Siri.

![siri1](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/155953822/18bfbf79-e208-4366-8bea-6499096dd819)

![siri2](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/155953822/6d1cca80-de94-4ae4-ae88-c5aa23b8b1fc)
