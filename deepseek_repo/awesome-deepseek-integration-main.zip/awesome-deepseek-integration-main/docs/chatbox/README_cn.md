<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/13600976/224d547a-6fbc-47c8-859f-aa14813e2b0f" width="64" height="auto" /> 

# [Chatbox](https://chatboxai.app/)

Chatbox 是一个支持多种流行LLM模型的桌面客户端，可在 Windows、Mac 和 Linux 上使用。

## UI

<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/13600976/cf5ebfd6-1e4d-478f-81fa-8d68d25b7414" />

## 配置 deepseek API

<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/13600976/926a87dc-ba2c-4929-9310-c4f1a18c0ce3" />
