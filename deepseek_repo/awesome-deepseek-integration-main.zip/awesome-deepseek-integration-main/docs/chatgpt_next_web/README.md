<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/bb65404c-f867-42d8-ae2b-281fe953ab54" width="64" height="auto" /> 

# [ChatGPT-Next-Web](https://github.com/ChatGPTNextWeb/ChatGPT-Next-Web)

One-Click to get a well-designed cross-platform ChatGPT web UI，support multiple LLMs.

## UI
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/3a827669-e5e4-4fc3-97d7-bcf57efb76d1)


## Integrate with Deepseek API
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/13600976/996363ca-21e3-42f0-8285-071b209f501f)
