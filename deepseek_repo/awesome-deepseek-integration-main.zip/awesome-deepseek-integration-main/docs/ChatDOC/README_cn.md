# [ChatDOC](https://chatdoc.com)

ChatDOC是一款AI文档阅读工具，具备强大的溯源功能，确保每一条信息的来源清晰可查，助您高效、精准地掌握文档核心。

## UI

![image](./assets/ui.png)

## Integrate with DeepSeek API

![image](./assets/settings.png)
