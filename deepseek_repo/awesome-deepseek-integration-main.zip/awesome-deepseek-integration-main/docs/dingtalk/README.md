![dingtalk.png](assets/dingtalk.png)

# DingTalk AI Assistant
Supports users in independently selecting different DeepSeek models for task inference.

- Currently, three major DeepSeek versions are available for user selection:
    - DeepSeek-R1 32B Distilled Version
    - DeepSeek-R1 671B Full-Power Version
    - DeepSeek-V3 671B Full-Power Version

![dingtalk_ai_assistant.png](assets/dingtalk_ai_assistant.png)