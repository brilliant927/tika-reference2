![dingtalk.png](assets/dingtalk.png)

#钉钉AI助理
支持用户自助选择deepseek不同模型进行任务推理
- 目前支持deepseek三个大版本可供用户自助选择
  - deepseek-R1 32B蒸馏版本
  - deepseek-R1 671B满血版本
  - deepseek-V3 671B满血版本


![dingtalk_ai_assistant.png](assets/dingtalk_ai_assistant.png)