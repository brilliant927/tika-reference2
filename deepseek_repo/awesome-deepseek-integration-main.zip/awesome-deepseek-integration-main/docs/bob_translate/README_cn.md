<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/96636a42-207e-43df-a683-02e10d13fe34" width="64" height="auto" /> 

# [Bob Translate](https://bobtranslate.com/)

在任意应用程序中使用 Bob 进行翻译和 OCR，即用即走，简单、快捷、高效！

## UI
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/9e2a0ac5-a284-4c82-bcd3-e7aefd9cd5a8)


## Integrate with Deepseek API
可以使用下面的插件(收费)来配置deepseek api.
https://github.com/openai-translator/bob-plugin-openai-translator
