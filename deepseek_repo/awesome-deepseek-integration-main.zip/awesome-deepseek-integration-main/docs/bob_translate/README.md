<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/96636a42-207e-43df-a683-02e10d13fe34" width="64" height="auto" /> 

# [Bob Translate](https://bobtranslate.com/)

Bob Translate is a translation and OCR application on Mac. Use it for translation and OCR, simple and efficient!

## UI
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/9e2a0ac5-a284-4c82-bcd3-e7aefd9cd5a8)


## Integrate with Deepseek API
To use the DeepSeek API, you have to download the plugin below for fee.
https://github.com/openai-translator/bob-plugin-openai-translator
