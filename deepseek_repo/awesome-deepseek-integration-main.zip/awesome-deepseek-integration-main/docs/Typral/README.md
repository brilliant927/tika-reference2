<img src="https://www.typral.com/_next/image?url=%2Ffavicon.ico&w=96&q=75" width="64" height="auto" />

# [Typral](https://www.typral.com)

Fast AI writer assistant - Let AI help you quickly improve article, paper, text...

## UI
<img src="./assets/screenshot1.png" width="360" height="auto" />

## 配置 Deepseek API
<img src="./assets/screenshot2.png" width="360" height="auto" />