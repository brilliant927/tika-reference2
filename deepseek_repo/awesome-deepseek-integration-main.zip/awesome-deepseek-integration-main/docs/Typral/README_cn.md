<img src="https://www.typral.com/_next/image?url=%2Ffavicon.ico&w=96&q=75" width="64" height="auto" />

# [Typral](https://www.typral.com)

超快的AI写作助手 - 让AI帮你快速优化日报,文章,文本等等...

## UI
<img src="./assets/screenshot1.png" width="360" height="auto" />

## 配置 Deepseek API
<img src="./assets/screenshot2.png" width="360" height="auto" />