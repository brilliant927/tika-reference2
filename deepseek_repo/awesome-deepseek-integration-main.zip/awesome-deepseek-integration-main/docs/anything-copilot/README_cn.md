# [**Anything Copilot**](https://github.com/baotlake/anything-copilot)

> <sub>![](./assets/logo_16x16.svg)</sub> Anything Copilot 是一款可以让你在侧边栏无缝使用任意主流AI工具的浏览器插件。例如，你可以在侧边栏中打开 DeepSeek 等 AI 聊天页面 ，把 DeekSeek 变成你的侧边栏中的 AI Copilot 。

**在 Chrome Web Store 安装**： [Anything Copilot - 更强大的侧边栏，分屏，AI 助手](https://chromewebstore.google.com/detail/anything-copilot-%E6%9B%B4%E5%BC%BA%E5%A4%A7%E7%9A%84%E4%BE%A7%E8%BE%B9%E6%A0%8F%EF%BC%8C/lilckelmopbcffmglfmfhelaajhjpcff?hl=zh)

**在 Edge Add-ons 安装**： [Anything Copilot - 更强大的侧边栏，分屏，AI 助手](https://microsoftedge.microsoft.com/addons/detail/anything-copilot-%E6%9B%B4%E5%BC%BA%E5%A4%A7%E7%9A%84%E4%BE%A7%E8%BE%B9/lbeehbkcmjaopnlccpjcdgamcabhnanl?hl=zh)


![](./assets/Screenshot_DeepSeek.webp)
