<img src="https://lh3.googleusercontent.com/K9i0qJb8phasC5wWf5tU68rhnfvX4swsE0hrhJP-WB3WV7MwE5KpMUIJvHKNHHRE6GKNIvIdTNSWoDMl_NggrmUsaw=s120" alt="Icon" width="64" height="auto" />

# [Immersive Reading Guide](https://chromewebstore.google.com/detail/immersive-reading-guide/jnjhalaghogaleoidplmjhjnemmakffp)

NO Sidebar!!! Immersive AI web summarization, ask questions...

## Preview

![image](https://github.com/glidea/pages/blob/main/immersive-reading-guide/concepts.png?raw=true)

![image](https://github.com/glidea/pages/blob/main/immersive-reading-guide/table-en.png?raw=true)

![image](https://github.com/glidea/pages/blob/main/immersive-reading-guide/ask-en.png?raw=true)

## Deepseek API

![image](https://github.com/glidea/pages/blob/main/immersive-reading-guide/deepseel-model-config-en.png?raw=true)

