<img src="https://lh3.googleusercontent.com/K9i0qJb8phasC5wWf5tU68rhnfvX4swsE0hrhJP-WB3WV7MwE5KpMUIJvHKNHHRE6GKNIvIdTNSWoDMl_NggrmUsaw=s120" alt="Icon" width="64" height="auto" />

# [沉浸式导读](https://chromewebstore.google.com/detail/immersive-reading-guide/jnjhalaghogaleoidplmjhjnemmakffp)

NO Sidebar!!! 沉浸式的 AI 网页摘要，提问...

## Preview

![image](https://github.com/glidea/pages/blob/main/immersive-reading-guide/concepts.png?raw=true)

![image](https://github.com/glidea/pages/blob/main/immersive-reading-guide/table.png?raw=true)

![image](https://github.com/glidea/pages/blob/main/immersive-reading-guide/ask.png?raw=true)

## Deepseek API

![image](https://github.com/glidea/pages/blob/main/immersive-reading-guide/deepseek-model-config.png?raw=true)

