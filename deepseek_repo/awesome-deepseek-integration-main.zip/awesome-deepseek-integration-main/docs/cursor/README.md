<img src="https://mintlify.s3-us-west-1.amazonaws.com/cursor/_generated/favicon/apple-touch-icon.png?v=3" width="64" height="auto" />

# [Cursor](https://www.cursor.com/)

  Cursor is the AI Code Editor

## Just follow these steps:

1. in Cursor Settings disable all models
2. add `deepseek-coder` as new model
3. in Open AI API Key add https://api.deepseek.com/beta as URL - add your API key.

# UI

![image](assets/cursor-setting.png)