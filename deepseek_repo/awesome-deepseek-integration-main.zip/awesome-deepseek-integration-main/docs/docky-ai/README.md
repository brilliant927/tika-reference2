<img src="http://cdn.docky.ai/assets/logo-with-text.svg" height="64" /> 

# [Docky AI](https://docky.ai)

[Docky AI](https://docky.ai) is a powerful browser extension that allows you to have real-time conversations with multiple AI models through a sidebar. It supports simultaneous communication with multiple models and can assist you in reading web pages, writing, translating, and creating images

## Installation
* [Chrome Extension](https://chromewebstore.google.com/detail/miaadkeokbokhcgfndeofmfffhpchfne)
* [Edge Extension](https://microsoftedge.microsoft.com/addons/detail/ifdhjlggobhfembihfpdogflohcdhdhl)

## UI
<img src="http://cdn.docky.ai/assets/snapshot.png" /> 
