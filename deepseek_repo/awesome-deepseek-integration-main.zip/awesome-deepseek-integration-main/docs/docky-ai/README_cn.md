<img src="http://cdn.docky.ai/assets/logo-with-text.svg" height="64" /> 

# [Docky AI](https://docky.ai)

[Docky AI](https://docky.ai) 是一款功能强大的浏览器插件，允许您通过侧边栏与多个 AI 模型进行实时对话。它支持多模型同时交流，并能协助您阅读网页、写作、翻译和创作图片

## Installation
* [Chrome Extension](https://chromewebstore.google.com/detail/miaadkeokbokhcgfndeofmfffhpchfne)
* [Edge Extension](https://microsoftedge.microsoft.com/addons/detail/ifdhjlggobhfembihfpdogflohcdhdhl)

## UI
<img src="http://cdn.docky.ai/assets/snapshot.png" /> 
