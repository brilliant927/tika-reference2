<img src="http://cdn.docky.ai/assets/logo-with-text.svg" height="64" /> 

# [Docky AI](https://docky.ai)

[Docky AI](https://docky.ai) は強力なブラウザ拡張機能で、サイドバーを通じて複数のAIモデルとリアルタイムで会話することができます。複数モデルとの同時交流をサポートし、ウェブページの閲覧、執筆、翻訳、画像作成を支援します

## Installation
* [Chrome Extension](https://chromewebstore.google.com/detail/miaadkeokbokhcgfndeofmfffhpchfne)
* [Edge Extension](https://microsoftedge.microsoft.com/addons/detail/ifdhjlggobhfembihfpdogflohcdhdhl)

## UI
<img src="http://cdn.docky.ai/assets/snapshot.png" /> 