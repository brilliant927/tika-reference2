<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/9d3f42b8-fcd0-47ab-8b06-1dd0554dd80e" width="64" height="auto" /> 

# [沉浸式翻译](https://immersivetranslate.com/)

沉浸式翻译是一款双语对照网页翻译插件.

## UI

![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/adf0f871-3ea6-4523-b892-57305bbe8de0)


## 配置 Deepseek API

![20240808-131028](https://github.com/user-attachments/assets/57c8fbc1-31d8-4d0c-9edd-6b75512feed1)

