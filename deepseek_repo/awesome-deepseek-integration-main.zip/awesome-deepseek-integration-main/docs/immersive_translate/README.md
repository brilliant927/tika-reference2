<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/9d3f42b8-fcd0-47ab-8b06-1dd0554dd80e" width="64" height="auto" /> 

# [Immersive Translate](https://immersivetranslate.com/)

Immersive Translate is a bilingual webpage translation plugin.

## UI

![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/adf0f871-3ea6-4523-b892-57305bbe8de0)


## Integrate with Deepseek API

![20240808-131028](https://github.com/user-attachments/assets/081f00ee-46b8-4227-9d20-e79ce2e68004)

