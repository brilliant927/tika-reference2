<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/8a301619-a3de-489b-81fd-69aaa7c1c561" width="64" height="auto" /> 

# [ChatGPT Box](https://github.com/josStorer/chatGPTBox)

将 LLMs 整合到你的浏览器中.

## UI
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/583b27ec-474a-4c29-aa93-cae44738b438)


## 配置 deepseek API
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/ab220788-fc68-4c68-b09e-87c620b03820)
