<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/8a301619-a3de-489b-81fd-69aaa7c1c561" width="64" height="auto" /> 

# [ChatGPT Box](https://github.com/josStorer/chatGPTBox)

ChatGPT Box is a deep LLMs integrations in your browser, completely for free.

## UI
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/583b27ec-474a-4c29-aa93-cae44738b438)


## Integrate with Deepseek API
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/ab220788-fc68-4c68-b09e-87c620b03820)
