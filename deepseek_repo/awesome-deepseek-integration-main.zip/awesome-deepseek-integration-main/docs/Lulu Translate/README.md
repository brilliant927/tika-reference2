<img src="https://static.eudic.net/web/trans/en_trans.png" width="64" height="auto" />

# [Lulu Translate](https://www.eudic.net/v4/en/app/plugins)

The plugin provides mouse selection translation, paragraph-by-paragraph comparison translation, and PDF document translation functionalities. It can utilize various translation engines, such as DeepSeek AI, Bing, GPT, Google, etc.

## UI

![image](https://static.eudic.net/web/homepage/en_pluginsWelcome_1908.png)
![image](https://static.eudic.net/web/homepage/en_pluginsWelcome_19003.png)

## Configure DeepSeek API

![image](assets/ScreenShot-2024-07-05-at-06.21.45.png)
