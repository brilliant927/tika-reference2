<img src="https://static.eudic.net/web/trans/en_trans.png" width="64" height="auto" />

# [欧路翻译](https://www.eudic.net/v4/en/app/plugins)

提供鼠标划词搜索、逐段对照翻译、PDF 文献翻译功能。可以使用支持 DeepSeek AI, Bing、GPT、Google 等多种翻译引擎。

## UI

![image](https://static.eudic.net/web/homepage/en_pluginsWelcome_1908.png)
![image](https://static.eudic.net/web/homepage/en_pluginsWelcome_19003.png)

## 配置 DeepSeek API

![image](assets/ScreenShot-2024-07-05-at-06.21.45.png)
