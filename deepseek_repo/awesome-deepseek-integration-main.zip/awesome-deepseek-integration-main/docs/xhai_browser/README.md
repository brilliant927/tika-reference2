<img src="./assets/logo_512.png" width="64" height="auto" /> <img src="./assets/desktop_512.png" width="64" height="auto" /> 

# [xhai Browser](https://www.dahai123.top/)


[xhai Browser](https://m.malink.cn/s/7JFfIv) is an Android desktop management & AI browser, DeepSeek is the default AI dialog engine.
He has the ultimate performance (0.2 seconds to start), slim size (apk 3M), no ads, ultra-fast ad blocking, multi-screen classification, screen navigation, multi-search box, a box multiple search!

xhai means "xiaohai" in Chinese, which means "extreme, high-performance, AI Browser" in English.

## UI

<img src="./assets/deepseek3-4t.jpg" width="360" height="auto" />
<img src="./assets/deepseek3-4_2t.jpg" width="360" height="auto" />
