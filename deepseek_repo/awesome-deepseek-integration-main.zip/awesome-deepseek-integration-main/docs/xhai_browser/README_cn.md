<img src="./assets/logo_512.png" width="64" height="auto" /> <img src="./assets/desktop_512.png" width="64" height="auto" /> 

# [小海浏览器](https://www.dahai123.top/)


[小海浏览器](https://m.malink.cn/s/7JFfIv)是安卓桌面管理&AI浏览器,DeepSeek是默认AI对话引擎
他有极致的性能(0.2秒启动),苗条的体型(apk 3M大),无广告,超高速广告拦截,多屏分类,屏幕导航,多搜索框,一框多搜


## UI

<img src="./assets/deepseek3-4t.jpg" width="360" height="auto" />
<img src="./assets/deepseek3-4_2t.jpg" width="360" height="auto" />


