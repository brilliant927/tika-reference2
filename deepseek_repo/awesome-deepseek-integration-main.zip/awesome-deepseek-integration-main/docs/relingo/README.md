<img src="https://relingo.net/assets/images/relingo-logo.png" width="64" height="auto" /> 

# [Relingo Ext](https://relingo.net/)

Build and master vocabulary while you browse website and watch youtube!

## UI

![Image](https://relingo.net/assets/images/step3.png)

## Integrate with Deepseek API

![Image](https://github.com/user-attachments/assets/277a570d-e77e-4eac-b468-0a3b9da04fc6)

