<img src="https://relingo.net/assets/images/relingo-logo.png" width="64" height="auto" /> 

# [Relingo 浏览器扩展](https://relingo.net/)

在浏览网页和观看YouTube视频的同时，构建并掌握词汇量！

## UI

![Image](https://relingo.net/assets/images/step3.png)

## Integrate with Deepseek API

![Image](https://github.com/user-attachments/assets/277a570d-e77e-4eac-b468-0a3b9da04fc6)

