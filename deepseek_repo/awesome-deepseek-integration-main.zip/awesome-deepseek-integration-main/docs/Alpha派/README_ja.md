<img src="./assets/favicon1.png" width="64" height="auto" /> 

# Alphaパイ

AI投資研究エージェント/次世代の金融情報エントリーポイント。投資家を代理して会議に出席し、AI議事録を取るほか、金融投資情報の検索・質問応答やエージェント駆使した定量分析など、投資研究業務を支援します。

## UI

<img src="./assets/Alpha派-0.png" width="360" height="auto" />

<img src="./assets/Alpha派-1.png" width="360" height="auto" />

<img src="./assets/Alpha派-2.png" width="360" height="auto" />
