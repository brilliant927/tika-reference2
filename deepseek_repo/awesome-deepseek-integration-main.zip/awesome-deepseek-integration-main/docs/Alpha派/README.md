<img src="./assets/favicon1.png" width="64" height="auto" /> 

# Alpha Pai

AI Research Assistant / The Next-Generation Financial Information Portal Driven by AI.<br>
Proxy for investors to attend meetings and take notes, as well as providing search and Q&A services for financial information and quantitative analysis for investment research.
## UI

<img src="./assets/Alpha派-0.png" width="360" height="auto" />

<img src="./assets/Alpha派-1.png" width="360" height="auto" />


<img src="./assets/Alpha派-2.png" width="360" height="auto" />
