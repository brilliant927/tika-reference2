<img src="./assets/favicon1.png" width="64" height="auto" /> 

# Alpha派

AI投研助理/AI驱动的新一代金融信息入口。代理投资者听会/记纪要，金融投资信息的搜索问答/定量分析等投资研究工作。

## UI

<img src="./assets/Alpha派-0.png" width="360" height="auto" />

<img src="./assets/Alpha派-1.png" width="360" height="auto" />

<img src="./assets/Alpha派-2.png" width="360" height="auto" />
