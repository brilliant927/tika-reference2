<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/1ac9791b-87f7-41d9-9282-a70698344e1d" width="64" height="auto" /> 

# [Pal - AI Chat Client](https://apps.apple.com/us/app/pal-ai-chat-client/id6447545085)

支持用户定制的聊天app，仅限于ios系统使用.

## UI

![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/4c514622-0073-43b0-86df-3f4b5d3c3514)


## 配置 deepseek API

![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/13600976/68ec290d-bc5f-4844-a3bf-29d3f39bf9ba)
