<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/c3d9d100-247a-41cc-97c1-10b01ed25e70" width="64" height="auto" /> 

# [hcfy](https://hcfy.app/)

hcfy (划词翻译) is a browser translation plugin that integrates multiple translation APIs and LLM APIs.

## UI
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/367a41b6-3277-4897-a53f-aaa17bb9dc53)


## Integrate with Deepseek API
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/13600976/b09c8c94-f0ce-4a83-9c97-3aaec58df712)
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/1aecc349-b0d9-46db-9e0f-0034e672cce4)
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/340188ac-617a-45df-a9b5-b1c47a4943a1)
