<img src="https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/c3d9d100-247a-41cc-97c1-10b01ed25e70" width="64" height="auto" /> 

# [划词翻译](https://hcfy.app/)

整合了多家翻译 API 以及 LLM API 的浏览器翻译插件.

## UI
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/367a41b6-3277-4897-a53f-aaa17bb9dc53)


## 配置 deepseek API
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/c28dad22-9102-4bb1-a32c-549472be5972)
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/1aecc349-b0d9-46db-9e0f-0034e672cce4)
![image](https://github.com/deepseek-ai/awesome-deepseek-integration/assets/59196087/340188ac-617a-45df-a9b5-b1c47a4943a1)
