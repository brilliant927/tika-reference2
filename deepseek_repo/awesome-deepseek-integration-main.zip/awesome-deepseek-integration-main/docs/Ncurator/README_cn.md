<img src="./assets/logo.png" width="64" height="auto" />

# [Ncurator](https://www.ncurator.com)

知识库AI问答助手-让AI帮助你整理与分析知识

## UI
<img src="./assets/screenshot1.png" width="360" height="auto" />

## 配置 Deepseek API
<img src="./assets/screenshot2.png" width="360" height="auto" />