<img src="./assets/logo.png" width="64" height="auto" />

# [Ncurator](https://www.ncurator.com)

Knowledge Base AI Q&A Assistant -
Let AI help you organize and analyze knowledge

## UI
<img src="./assets/screenshot3.png" width="360" height="auto" />

## Integrate with Deepseek API
<img src="./assets/screenshot2.png" width="360" height="auto" />