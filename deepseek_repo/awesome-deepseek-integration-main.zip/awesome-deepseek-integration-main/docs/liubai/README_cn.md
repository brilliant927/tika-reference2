<img src="./assets/liubai-logo.png" width="64" height="auto" /> 

# [Liubai](https://github.com/yenche123/liubai)

让 DeepSeek 直接在微信上管理你的笔记、任务、日程和待办清单！

## UI

<img src="./assets/screenshot01.jpg" width="360" height="auto" />

<img src="./assets/screenshot02.jpg" width="360" height="auto" />

