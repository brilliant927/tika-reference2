<img src="https://github.com/kangfenmao/cherry-studio/blob/main/resources/icon.png?raw=true" width="64" height="auto" style="border-radius: 15px" /> 

# [Cherry Studio](https://github.com/kangfenmao/cherry-studio)

Cherry Studio 是一款为创造者而生的 AI 软件，支持多种大语言模型。

## 界面截图

<img src="https://camo.githubusercontent.com/c85d1d1ec8964a3b9c231714a10f3b1179357d20c21fcb0d54117bc45fa77928/68747470733a2f2f73322e6c6f6c692e6e65742f323032342f30372f31362f494156534f6f72736646517947684d2e706e67" />

## 配置 deepseek API

![](https://raw.githubusercontent.com/kangfenmao/assets/main/images/202407161306874.png)

## Cherry Studio 下载地址

项目主页：https://github.com/kangfenmao/cherry-studio  
下载地址：https://github.com/kangfenmao/cherry-studio/releases  