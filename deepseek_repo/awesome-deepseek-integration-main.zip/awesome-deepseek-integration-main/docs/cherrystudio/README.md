<img src="https://github.com/kangfenmao/cherry-studio/blob/main/resources/icon.png?raw=true" width="64" height="auto" style="border-radius: 15px" /> 

# [Cherry Studio](https://github.com/kangfenmao/cherry-studio)

Cherry Studio: A powerful desktop AI assistant for producer

## Screenshot

<img src="https://camo.githubusercontent.com/c85d1d1ec8964a3b9c231714a10f3b1179357d20c21fcb0d54117bc45fa77928/68747470733a2f2f73322e6c6f6c692e6e65742f323032342f30372f31362f494156534f6f72736646517947684d2e706e67" />

## Integrate with Deepseek API

![](https://raw.githubusercontent.com/kangfenmao/assets/main/images/202407161307342.png)

## Download Cherry Studio

Homepage：https://github.com/kangfenmao/cherry-studio  
Download：https://github.com/kangfenmao/cherry-studio/releases  