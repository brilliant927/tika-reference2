<img src="https://raw.githubusercontent.com/rss-translator/RSS-Translator/main/core/static/favicon.ico" width="64" height="auto" /> 

# [RSS翻译器](https://rsstranslator.com/)

一个开源、简洁、可自部署的RSS翻译器，可翻译标题/内容、AI总结，并输出翻译后的RSS订阅链接。

## UI

![UI](assets/ui.png)

## 配置 deepseek API

![add_translator](assets/add_translator.png)
![add_openai](assets/add_openai.png)