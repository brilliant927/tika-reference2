
import { DonutImageProcessor } from "../donut/image_processing_donut.js";

// NOTE: extends DonutImageProcessor
export class NougatImageProcessor extends DonutImageProcessor { }
