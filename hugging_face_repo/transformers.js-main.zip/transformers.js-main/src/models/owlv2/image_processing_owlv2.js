
import { OwlViTImageProcessor } from "../owlvit/image_processing_owlvit.js";

// NOTE: extends OwlViTImageProcessor
export class Owlv2ImageProcessor extends OwlViTImageProcessor { }
