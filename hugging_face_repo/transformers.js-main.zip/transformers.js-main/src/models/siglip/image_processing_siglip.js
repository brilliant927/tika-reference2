import { 
    ImageProcessor,
} from "../../base/image_processors_utils.js";

export class SiglipImageProcessor extends ImageProcessor { }
