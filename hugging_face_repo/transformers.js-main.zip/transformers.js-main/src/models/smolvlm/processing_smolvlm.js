
export { Idefics3Processor as SmolVLMProcessor } from "../idefics3/processing_idefics3.js";
