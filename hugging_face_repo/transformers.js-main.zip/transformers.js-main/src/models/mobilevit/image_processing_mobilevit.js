import { 
    ImageProcessor,
} from "../../base/image_processors_utils.js";

export class MobileViTImageProcessor extends ImageProcessor { }
export class MobileViTFeatureExtractor extends MobileViTImageProcessor { }
