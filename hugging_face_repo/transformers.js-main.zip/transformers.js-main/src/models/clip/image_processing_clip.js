import { 
    ImageProcessor,
} from "../../base/image_processors_utils.js";

export class CLIPImageProcessor extends ImageProcessor { }
export class CLIPFeatureExtractor extends CLIPImageProcessor { }
