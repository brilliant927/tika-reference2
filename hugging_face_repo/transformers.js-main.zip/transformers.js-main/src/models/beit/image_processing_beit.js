import { 
    ImageProcessor,
} from "../../base/image_processors_utils.js";

export class BeitFeatureExtractor extends ImageProcessor { }
