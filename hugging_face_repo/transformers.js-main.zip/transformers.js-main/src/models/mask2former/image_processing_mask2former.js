
import { MaskFormerImageProcessor } from "../maskformer/image_processing_maskformer.js";

// NOTE: extends MaskFormerImageProcessor
export class Mask2FormerImageProcessor extends MaskFormerImageProcessor { }
