import { 
    ImageProcessor,
} from "../../base/image_processors_utils.js";

export class DeiTImageProcessor extends ImageProcessor { }
export class DeiTFeatureExtractor extends DeiTImageProcessor { }