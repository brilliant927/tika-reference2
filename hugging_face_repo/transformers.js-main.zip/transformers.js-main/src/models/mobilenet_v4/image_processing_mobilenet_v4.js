import { 
    ImageProcessor,
} from "../../base/image_processors_utils.js";


export class MobileNetV4ImageProcessor extends ImageProcessor { }
export class MobileNetV4FeatureExtractor extends MobileNetV4ImageProcessor { }
