
import { FeatureExtractor } from "../../base/feature_extraction_utils.js";

export class SpeechT5FeatureExtractor extends FeatureExtractor { }
