import { 
    ImageProcessor,
} from "../../base/image_processors_utils.js";


export class MobileNetV2ImageProcessor extends ImageProcessor { }
export class MobileNetV2FeatureExtractor extends MobileNetV2ImageProcessor { }
