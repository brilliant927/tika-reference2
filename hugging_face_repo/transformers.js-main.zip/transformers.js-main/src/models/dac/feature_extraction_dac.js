import { EncodecFeatureExtractor } from '../encodec/feature_extraction_encodec.js';

export class DacFeatureExtractor extends EncodecFeatureExtractor { }
