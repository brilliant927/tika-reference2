import { DacFeatureExtractor } from '../dac/feature_extraction_dac.js';

export class SnacFeatureExtractor extends DacFeatureExtractor { }
