import { 
    ImageProcessor,
} from "../../base/image_processors_utils.js";


export class MobileNetV3ImageProcessor extends ImageProcessor { }
export class MobileNetV3FeatureExtractor extends MobileNetV3ImageProcessor { }
