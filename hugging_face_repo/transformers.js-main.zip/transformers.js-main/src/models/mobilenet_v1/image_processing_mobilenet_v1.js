import { 
    ImageProcessor,
} from "../../base/image_processors_utils.js";


export class MobileNetV1ImageProcessor extends ImageProcessor { }
export class MobileNetV1FeatureExtractor extends MobileNetV1ImageProcessor { }
