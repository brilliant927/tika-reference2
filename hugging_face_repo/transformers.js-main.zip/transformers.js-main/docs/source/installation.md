# Installation

<include>
{
    "path": "../snippets/2_installation.snippet"
}
</include>
