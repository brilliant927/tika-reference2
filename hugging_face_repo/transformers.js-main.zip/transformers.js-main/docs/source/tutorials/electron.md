# Building an Electron application

*Full tutorial coming soon...* In the meantime, check out the example application: https://github.com/huggingface/transformers.js/tree/main/examples/electron
